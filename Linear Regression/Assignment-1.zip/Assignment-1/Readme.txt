Programming language: PYTHON
Libraries that are expected to be pre-installed.
		 panda
		 numpy
		 seaborn
		 matplotlib.pyplot
How to run code:
	oChange directory to assignment folder 
	oType command in command line: py linear_regression.py 
	(or)
	o Run python script in Python IDLE.
